import { getDatabase } from '../../database/database';
import { getDatasetCount } from '../../database/repositories/DataRepository';
import SYNC_DATASETS from './configs';
import {
    beginSyncBatch,
    endSyncBatch,
    syncDataWithinBatch,
    type SyncDataset,
} from './syncData';

export interface SyncAllResult {
    synchronized: string[];
    skipped: string[];
}

let activeSyncAll: Promise<SyncAllResult> | null = null;

/** Sincroniza datasets pendentes; force=true refaz todos. */
export function syncAllData(
    options: {
        force?: boolean;
        onDatasetProgress?: (dataset: string, saved: number, totalFetched: number) => void;
    } = {},
): Promise<SyncAllResult> {
    // Reutiliza a mesma operação se o startup e o botão chamarem juntos.
    if (activeSyncAll) {
        console.log('[Sync] Sincronização geral já ativa; reutilizando a operação atual.');
        return activeSyncAll;
    }

    // Reserva o lock antes de executar qualquer SELECT/COUNT no SQLite.
    if (!beginSyncBatch()) {
        return Promise.reject(
            new Error('Já existe uma sincronização em andamento. Aguarde sua conclusão.'),
        );
    }

    const operation = runSyncAll(options);
    activeSyncAll = operation;

    return operation.finally(() => {
        if (activeSyncAll === operation) activeSyncAll = null;
        endSyncBatch();
    });
}

async function runSyncAll(
    options: {
        force?: boolean;
        onDatasetProgress?: (dataset: string, saved: number, totalFetched: number) => void;
    },
): Promise<SyncAllResult> {
    const database = await getDatabase();
    const synchronized: string[] = [];
    const skipped: string[] = [];

    for (const config of SYNC_DATASETS as readonly SyncDataset[]) {
        const state = await database.getFirstAsync<{
            status: string;
            record_count: number;
        }>(
            'SELECT status, record_count FROM sync_state WHERE dataset = ?',
            config.dataset,
        );
        const actualCount = await getDatasetCount(database, config.databaseTable);
        const needsSync = options.force === true || !state || state.status !== 'completed' || state.record_count !== actualCount;

        if (!needsSync) {
            skipped.push(config.dataset);
            console.log(`[Sync] ${config.dataset}: já está sincronizada (${actualCount}).`);
            continue;
        }

        console.log(`[Sync] ${config.dataset}: sincronização necessária.`);
        await syncDataWithinBatch(config, (saved, totalFetched) => {
            options.onDatasetProgress?.(config.dataset, saved, totalFetched);
        });
        synchronized.push(config.dataset);
    }

    return { synchronized, skipped };
}
