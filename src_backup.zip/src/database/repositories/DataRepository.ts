import type { SQLiteDatabase } from 'expo-sqlite';
import * as he from 'he';

export type DatabaseRow = Record<string, unknown>;

function assertIdentifier(identifier: string, label: string): void {
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(identifier)) {
        throw new Error(`${label} inválido: ${identifier}`);
    }
}

// Os nomes dos campos Cargo devem ser preservados exatamente.
function toDatabaseColumn(key: string): string {
    return key.trim().replace(/[\s-]+/g, '_');
}

function normalizeValue(value: unknown): string | number | null {
    if (value == null) return null;
    if (typeof value === 'string') return he.decode(value);
    if (typeof value === 'boolean') return value ? 1 : 0;
    if (typeof value === 'number') return value;
    return JSON.stringify(value);
}

function normalizeRow(row: DatabaseRow): Record<string, unknown> {
    const normalized: Record<string, unknown> = {};

    for (const [key, value] of Object.entries(row)) {
        normalized[toDatabaseColumn(key)] = value;
    }

    if (normalized.id == null) {
        throw new Error('Registro Cargo sem identificador "id". Verifique o alias no campo Cargo.');
    }

    return normalized;
}

/**
 * Salva um lote em uma transação exclusiva. Se o SQLite estiver temporariamente
 * ocupado por outra operação, repete o lote inteiro após o rollback automático.
 */
export async function saveDataset(
    database: SQLiteDatabase,
    databaseTable: string,
    rows: DatabaseRow[],
): Promise<number> {
    assertIdentifier(databaseTable, 'Nome da tabela');
    if (rows.length === 0) return 0;

    const normalizedRows = rows.map((row) => {
        const normalized = normalizeRow(row);
        for (const column of Object.keys(normalized)) {
            assertIdentifier(column, 'Nome da coluna');
        }
        return normalized;
    });


    const maxAttempts = 5;
    for (let attempt = 0; ; attempt++) {
        try {
            await database.withExclusiveTransactionAsync(async (transaction) => {
                for (const row of normalizedRows) {
                    const columns = Object.keys(row);
                    const columnSql = columns.map((column) => `"${column}"`).join(', ');
                    const placeholders = columns.map(() => '?').join(', ');
                    const updates = columns
                        .filter((column) => column !== 'id')
                        .map((column) => `"${column}" = excluded."${column}"`)
                        .join(', ');
                    const sql = updates
                        ? `INSERT INTO "${databaseTable}" (${columnSql}) VALUES (${placeholders}) ON CONFLICT("id") DO UPDATE SET ${updates};`
                        : `INSERT INTO "${databaseTable}" (${columnSql}) VALUES (${placeholders}) ON CONFLICT("id") DO NOTHING;`;
                    const values = columns.map((column) => normalizeValue(row[column]));
                    await transaction.runAsync(sql, ...values);
                }
            });
            return normalizedRows.length;
        } catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            const isLocked = /database is locked|database table is locked|SQLITE_BUSY|SQLITE_LOCKED/i.test(message);

            if (!isLocked || attempt >= maxAttempts - 1) {
                throw error;
            }

            const delayMs = Math.min(500 * 2 ** attempt, 8000);
            console.warn(
                `[SQLite] Banco ocupado ao salvar ${databaseTable}; tentativa ${attempt + 2}/${maxAttempts} em ${delayMs} ms.`,
            );
            await new Promise<void>((resolve) => setTimeout(resolve, delayMs));
        }
    }
}

export async function getDatasetCount(
    database: SQLiteDatabase,
    databaseTable: string,
): Promise<number> {
    assertIdentifier(databaseTable, 'Nome da tabela');

    const result = await database.getFirstAsync<{ total: number }>(
        `SELECT COUNT(*) AS total FROM "${databaseTable}"`,
    );

    return result?.total ?? 0;
}
